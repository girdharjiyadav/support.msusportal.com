﻿$(document).ready(function () {
    alert('hi');
    $("#lnk-services").addClass("active");

    $("#btnsubmit").click(function (e) {
        debugger
        var valid = true;
        if ($("[name='txtfname']").val().trim() == '') {
            alert("Please enter First name.");
            $("[name='txtfname']").focus();
            valid = false;
        }
        else if ($("[name='txtlname']").val().trim() == '') {
            alert("Please enter Last name.");
            $("#[name='txtlname']").focus();
            valid = false;
        }
        else if ($("[name='txtlname']").val().trim() == '') {
            alert("Please enter Last name.");
            $("#[name='txtlname']").focus();
            valid = false;
        }
        else if ($("[name='txtpassword']").val().trim() == '') {
            alert("Please enter Password.");
            $("#[name='txtpassword']").focus();
            valid = false;
        }
        else if ($("[name='txtcontact']").val().trim() == '') {
            alert("Please enter Contact No.");
            $("#[name='txtcontact']").focus();
            valid = false;
        }
        else if ($("[name='ddlProofType']").val().trim() == '0') {
            alert("Please select ID Proof type");
            $("#[name='ddlProofType']").focus();
            valid = false;
        }
        else if ($("[name='txtidproofno']").val().trim() == '') {
            alert("Please enter ID proof No.");
            $("#[name='txtidproofno']").focus();
            valid = false;
        }
        else if ($("[name='txtcountry']").val().trim() == '') {
            alert("Please enter Country.");
            $("#[name='txtcountry']").focus();
            valid = false;
        }
        else if ($("[name='txtstate']").val().trim() == '') {
            alert("Please enter State");
            $("#[name='txtstate']").focus();
            valid = false;
        }
        else if ($("[name='txtcity']").val().trim() == '') {
            alert("Please enter City");
            $("#[name='txtcity']").focus();
            valid = false;
        }
        else if ($("[name='txtZip']").val().trim() == '') {
            alert("Please enter Zip Code");
            $("#[name='txtZip']").focus();
            valid = false;
        }
            //Compare password and Confirm Password
        else if ($("[name='txtpassword']").val().trim() != $("[name='txtcpass']").val().trim()) {
            alert("Confirm password not match");
            $("#[name='txtcpass']").focus();
            valid = false;
        }
        //validate email
        //var email = $('#txtemails').val(),
        //    emailReg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        //if(!emailReg.test(String(email).toLowerCase()) || email == '')
        //{
        //    alert('Please enter a valid email address.');
        //    valid = false;
        //}

        const email = document.querySelector('input[name=txtemails]');
        //const button = document.querySelector('#btn');
        //const text = document.querySelector('#message');

        const validateEmail = email => {
            var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return regex.test(String(email).toLowerCase());
            };

    if(validateEmail(email.value))
    {
        alert('Please enter a valid email address.');
        valid = false;
    }
        //    button.addEventListener('click', () => {
        //        if (validateEmail(email.value)) {
        //        text.innerText = "Valid email";
        //} else {
        //    text.innerText = "Invalid email";
        //}
        //});

        //END


        //validate phone
        //var phone = $('#txtcontact').val(),
        //    intRegex = '/[0-9 -()+]+$/';
        //if((phone.length < 6) || (!intRegex.test(phone)))
        //{
        //    alert('Please enter a valid phone number.');
        //    valid = false;
        //}
           
      
        if (valid == true) {
            $('form#frm').submit();;
        }
    });
});

